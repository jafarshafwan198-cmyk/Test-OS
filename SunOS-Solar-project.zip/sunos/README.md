# SunOS — Solar (Tahap 1: ISO Live Linux)

SunOS adalah proyek distro turunan Debian 12 (Bookworm) 64-bit yang memakai kernel Linux, systemd, XFCE, GRUB, Chromium, Thunar, XFCE Terminal, dan Mousepad yang diberi nama menu **SunOS Notepad**.

> **Status jujur:** paket proyek ini berisi konfigurasi build yang dapat dijalankan di lingkungan Debian/Ubuntu Linux. ISO belum dibangun atau diuji di VirtualBox dalam sesi ini. Tahap ini menargetkan ISO Live yang dapat di-boot; installer grafis ke disk, animasi login khusus, dan tema menyeluruh masih perlu tahap lanjutan. Jangan menganggap fitur yang belum diuji sebagai sudah berfungsi.

## Persyaratan build

- Komputer/VM Linux x86_64 berbasis Debian atau Ubuntu.
- Ruang kosong disarankan 25 GB atau lebih.
- RAM 8 GB disarankan.
- Koneksi internet untuk mengambil paket.
- VirtualBox untuk menguji ISO.

## Isi tahap ini

- Debian Live + XFCE; kernel dan init system Linux asli.
- GRUB untuk boot ISO.
- Chromium (alternatif open-source untuk Chrome), terminal Bash sungguhan, Thunar, dan Mousepad yang diberi label SunOS Notepad.
- Pengaturan branding dasar dan wallpaper SVG.
- Nama pengguna live diminta sebagai `Jafar`. Login pada sesi live dapat memakai autologin bawaan Debian Live; password `Andien1234` **belum dikonfigurasi** pada tahap ini agar password tidak ditanam sebagai teks biasa di konfigurasi ISO. Pengaturan password aman dan login untuk sistem terpasang perlu diselesaikan bersama installer pada tahap lanjutan.
- Jaringan memakai konfigurasi DHCP standar Debian Live. Di VirtualBox pilih NAT.

## Bangun ISO

Jalankan dari direktori proyek ini di Debian/Ubuntu Linux, bukan PowerShell/Windows biasa:

```bash
sudo apt update
sudo apt install -y live-build debootstrap squashfs-tools xorriso grub-pc-bin grub-efi-amd64-bin mtools
chmod +x build.sh
sudo ./build.sh
```

Build memerlukan akses internet dan dapat memakan waktu cukup lama. Hasil yang diharapkan: `live-image-amd64.hybrid.iso` di direktori proyek.

Jika build gagal karena mirror atau versi paket, lihat output terminal dan `config/` lalu coba lagi setelah memperbarui paket host. Jangan menjalankan skrip build dari dalam SunOS live image tanpa ruang disk yang cukup.

## Uji di VirtualBox

Buat VM baru:
- Type: Linux
- Version: Debian (64-bit)
- RAM: 4096 MB minimum, 8192 MB disarankan
- CPU: 2 minimum, 4 disarankan jika host mampu
- Disk virtual: 40 GB jika ingin menyiapkan instalasi di tahap berikutnya
- Network: NAT
- Audio: aktif
- ISO: pilih `live-image-amd64.hybrid.iso`

Mulai VM dan pilih opsi Live dari menu GRUB. Setelah desktop muncul, sesi live dapat masuk otomatis atau meminta login sesuai perilaku paket Debian Live. Password khusus SunOS belum disetel pada tahap ini.

## Setelah masuk

```bash
passwd                 # ganti password akun live
sudo apt update
sudo apt install htop git python3 nano
```

Akun dan file yang dibuat dalam mode live biasanya tidak bertahan setelah shutdown kecuali live persistence dikonfigurasi. Jangan simpan data penting di sesi live.

## Catatan aplikasi

- **Browser:** Chromium nyata dari repositori Debian; bukan Google Chrome. Google Chrome dapat dipasang terpisah dari paket resmi Google jika diinginkan dan jika arsitektur didukung.
- **Terminal:** XFCE Terminal menjalankan Bash dan perintah Linux asli.
- **File manager:** Thunar mengakses filesystem nyata sesuai izin Linux.
- **SunOS Notepad:** label menu menjalankan Mousepad, editor teks GTK nyata. File tersimpan pada filesystem yang sebenarnya.
- **Bahasa “L”:** belum ditambahkan karena “bahasa L” tidak cukup spesifik untuk menentukan bahasa pemrograman/interpreter yang dimaksud. Bash adalah shell standar.

## Masalah umum

- **ISO tidak boot:** pastikan build selesai sukses, file ISO ada dan berukuran masuk akal; pilih Debian (64-bit), dan coba EFI off terlebih dahulu.
- **Tidak ada internet:** pastikan adapter VM aktif dan disetel NAT; di dalam sistem periksa `ip addr`, `ip route`, lalu `ping -c 3 1.1.1.1`.
- **DNS gagal:** periksa `ping -c 3 deb.debian.org`.
- **Layar terlalu kecil:** pasang VirtualBox Guest Additions pada sistem terpasang atau uji pengaturan display VirtualBox. Dukungan resize live dapat bergantung pada driver.
- **Periksa log:** `journalctl -b -p warning`, `dmesg`, dan `/var/log/`.

## Keamanan

Password akun `Andien1234` belum diterapkan pada tahap awal ini. Jangan menanam password teks biasa di skrip build atau parameter boot karena dapat dibaca dari ISO. Pada tahap installer, buat akun dan tetapkan password melalui mekanisme sistem yang aman.

## Roadmap tahap berikutnya

1. Uji boot ISO di VirtualBox.
2. Tambahkan installer disk yang dikonfigurasi dan diuji.
3. Integrasikan tema XFCE, Plymouth, avatar, lock screen, ikon dan wallpaper final.
4. Tambahkan pengelola aplikasi grafis serta pengujian otomatis.
