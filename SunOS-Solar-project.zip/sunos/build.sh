#!/usr/bin/env bash
set -Eeuo pipefail
cd "$(dirname "$0")"

if [[ "$(uname -s)" != "Linux" || "$(uname -m)" != "x86_64" ]]; then
  echo "Build SunOS harus dijalankan di Linux x86_64." >&2
  exit 1
fi
if ! command -v lb >/dev/null 2>&1; then
  echo "live-build belum terpasang. Jalankan: sudo apt install live-build" >&2
  exit 1
fi
if [[ $EUID -ne 0 ]]; then
  echo "Jalankan dengan sudo: sudo ./build.sh" >&2
  exit 1
fi

# live-build menggunakan direktori kerja saat ini sebagai konfigurasi proyek.
lb clean --purge || true
lb config \
  --mode debian \
  --distribution bookworm \
  --architectures amd64 \
  --binary-images iso-hybrid \
  --archive-areas "main contrib non-free-firmware" \
  --debian-installer false \
  --bootappend-live "boot=live components username=Jafar hostname=sunos-pc locales=id_ID.UTF-8 keyboard-layouts=id" \
  --iso-application "SunOS Solar" \
  --iso-volume "SUNOS_SOLAR" \
  --apt-recommends true \
  --memtest none

lb build

if [[ -f live-image-amd64.hybrid.iso ]]; then
  echo "Selesai: $(pwd)/live-image-amd64.hybrid.iso"
else
  echo "Build selesai tetapi ISO pada nama yang diharapkan tidak ditemukan. Periksa output live-build." >&2
  find . -maxdepth 2 -type f -name '*.iso' -print
fi
