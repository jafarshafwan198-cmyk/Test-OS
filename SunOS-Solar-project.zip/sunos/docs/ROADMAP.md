# Roadmap implementasi

## Tahap 1 — basis bootable
Konfigurasi saat ini memakai Debian Live, XFCE, GRUB, Chromium, terminal, Thunar, dan Mousepad. Uji ISO sebelum melanjutkan.

## Tahap 2 — instalasi ke disk
Pilih dan integrasikan installer yang teruji (misalnya Calamares dengan konfigurasi Debian yang benar), termasuk pembuatan user, partisi, dan pemasangan bootloader. Jangan menyalin kredensial live secara otomatis ke instalasi.

## Tahap 3 — branding lengkap
Buat tema LightDM, tema GRUB dan Plymouth khusus, ikon SunOS, kursor, serta konfigurasi taskbar/menu XFCE.

## Tahap 4 — pengujian
Uji boot BIOS dan EFI, login, jaringan DHCP/DNS, Chromium dan video, unduh file, aplikasi, suspend/restart/shutdown, resolusi dinamis, dan instalasi disk pada VM bersih.
